import os, json

try:
    import discord
except Exception as e:
    os.system('pip install discord')
try:
    import pymysql
except Exception as e:
    os.system('pip install pymysql')

client = discord.Client(intents = discord.Intents.all())

with open("setting.json", 'r', encoding='utf-8') as f:
    haley = json.load(f)

def check_DB():
    try:
        SQL = pymysql.connect(host = haley['sql']['host'], user = haley['sql']['user'], password = haley['sql']['password'], db = haley['sql']['db_name'], charset = 'utf8')
        db = SQL.cursor()
        return SQL, db
    except:
        return False, False

@client.event
async def on_ready():
    print(f'{client.user} ( {client.user.id} ) Login')

@client.event
async def on_message(message):
    if message.author.bot: 
        return
    elif message.channel.type == discord.ChannelType.private:
        return
    elif message.guild.id != int(haley['basic']['guild_id']):
        return
    elif message.channel.id != int(haley['basic']['channel_id']):
        return
    elif message.content.startswith(client.user.mention):
        return
    db, SQL = check_DB()
    if db == False: 
        return await message.channel.send('데이터베이스 연결이 불가능 합니다.')
    if message.content.startswith("뉴비인증#"):
        _code = message.content[5:]
        print(_code)
        try:
            SQL.execute(f'SELECT user_id FROM vrp_newbie_bonus WHERE code = "{_code}"')
            newbie_userid = SQL.fetchone()[0]
        except Exception as e:
            await message.channel.send('오류가 발생했습니다. 관리팀에게 문의해 주세요.')
        try:
            SQL.execute(f'SELECT user_id FROM vrp_user_ids WHERE identifier = "discord:{message.author.id}"')
            ids_userid = SQL.fetchone()[0]
        except Exception as e:
            await message.channel.send('오류가 발생했습니다. 관리팀에게 문의해 주세요.')
        if newbie_userid != ids_userid:
            await message.channel.send(f'유저 인증에 실패 했습니다. 관리팀에게 문의해 주세요 \n> ⚠ ERROR CODE - id0x0201 ⚠')
        else:
            await message.author.add_roles(message.guild.get_role(int(haley['basic']['role_id'])))
            SQL.execute(f'UPDATE vrp_newbie_bonus SET state = "1" WHERE user_id = "{newbie_userid}"')
            db.commit()
            await message.channel.send('인증이 정상적으로 완료 되었습니다.')
        SQL.execute(f'SELECT user_id FROM vrp_user_ids WHERE identifier = "discord:{message.author.id}"')
        ids_userid = SQL.fetchone()[0]
        SQL.execute(f'SELECT state FROM vrp_newbie_bonus WHERE user_id = {ids_userid}')
        _st = SQL.fetchone()[0]
        if _st == 2:
            await message.channel.send('이미 인증이 완료 된 유저 입니다.')

client.run(haley['basic']['token'])