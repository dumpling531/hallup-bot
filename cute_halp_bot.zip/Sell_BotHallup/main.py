import discord, subprocess, time, json, asyncio
from datetime import datetime, timedelta
from discord.ext import commands
from urllib.request import Request, urlopen
from discord_webhook import DiscordWebhook, DiscordEmbed
from discord_components import DiscordComponents, Button, ButtonStyle

app = commands.Bot(command_prefix='!', intents = discord.Intents.all())
logo_img = 'https://cdn.discordapp.com/attachments/935440032234369035/936625573659308112/logo.png'
now = datetime.now()
now_2 = now.strftime("%p %I : %M : %S".encode('unicode-escape').decode()).encode().decode('unicode-escape').replace("AM", "오전").replace("PM", "오후")


@app.command(name = '도움말')
async def help(ctx):
    await ctx.author.send(embed = discord.Embed(
        title = '공지 봇 도움말',
        description = f"""
        `{app.command_prefix[0]}공지 <1> <2> <3> <4>`
        <1> - 일동 또는 담당 (일동은 관리진 일동으로 공지를 작성) (담당은 담당관리자로 공지를 작성)
        <2> - notev 또는 ev (notev는 everyone없는 공지를 작성) (ev는 everyone가 있는 공지를 작성)
        <3> - 공지 제목 (`_`로 띄어 쓰기가 가능하다 안녕_하세요)
        <4> - 공지 내용 (공지의 내용을 작성 하면 됩니다.)""",
        color = 0x007bff
    ))

@app.command(name = '공지')
async def notiy(ctx, if_text: str = None, if_text1: str = None, text1: str = None, *, text: str = None):
    text1 = text1.replace('_', ' ')
    if text1 is None: return await ctx.send(f'ERROR CODE - Tx012')
    if text is None: return await ctx.send(f'ERROR CODE - Tx014')
    now = datetime.now().strftime("%p %I : %M : %S".encode('unicode-escape').decode()).encode().decode('unicode-escape').replace("AM", "오전").replace("PM", "오후")
    if if_text == '일동': 
        if if_text1 == 'notev':
            await app.get_channel(936622193834618890).send(embed = discord.Embed(title = f'{text1}', description = f'{text}', color = 0x00ff08).set_footer(text=f'관리진 일동ㆍ{now}', icon_url=logo_img).set_thumbnail(url=logo_img))

        elif if_text1 == 'ev':
            mb = 0
            for member in ctx.guild.members:
                mb += 1
            if mb >= 100: 
                emb = discord.Embed(title = '100명 이상 everyone경고 알림', color=0xff0000)
                emb.set_author(name=f"🛑 주의 🛑 아래의 내용을 확인해 주세요 ‼️")
                mesge = await ctx.send(embed=emb)
                await mesge.add_reaction('✅')
                await mesge.add_reaction('❌')
                try:
                    reaction, ctx.author = await app.wait_for(' reaction_add', timeout = 20, check = lambda reaction, author1: author1 == ctx.message.author and str(reaction.emoji) in ['✅', '❌'])
                except asyncio.TimeoutError:
                    await ctx.send('시간이 초과되었습니다.')
                else:
                    if str(reaction.emoji) == "❌":
                        await ctx.send("공지 작성을 취소 하였습니다.")
                        await asyncio.sleep(2.5)
                        await mesge.delete()
                    elif str(reaction.emoji) == "✅":
                        await mesge.delete()
                        await app.get_channel(936622193834618890).send('@everyone', embed = discord.Embed(title = f'{text1}', description = f'{text}', color = 0x00ff08).set_footer(text=f'관리진 일동ㆍ{now}', icon_url=logo_img).set_thumbnail(url=logo_img))
            else:
                await app.get_channel(936622193834618890).send('@everyone', embed = discord.Embed(title = f'{text1}', description = f'{text}', color = 0x00ff08).set_footer(text=f'관리진 일동ㆍ{now}', icon_url=logo_img).set_thumbnail(url=logo_img))
        else:
            await ctx.send('명령어 입력이 잘못 되었습니다. \n`notev - 애브리원 안함`, `ev - 애브리원 함`')
    
    elif if_text == '담당': 
        if if_text1 == 'noetev':
            await app.get_channel(936622193834618890).send(embed = discord.Embed(title = f'{text1}', description = f'{text}', color = 0x00ff08).set_footer(text=f'담당 관리자 : {ctx.author.display_name}ㆍ{now}', icon_url=logo_img).set_thumbnail(url=logo_img))
        
        elif if_text1 == 'ev':
            mb = 0
            for member in ctx.guild.members:
                mb += 1
            if mb >= 100: 
                emb = discord.Embed(title = '100명 이상 everyone경고 알림', color=0xff0000)
                emb.set_author(name=f"🛑 주의 🛑 아래의 내용을 확인해 주세요 ‼️")
                mesge = await ctx.send(embed=emb)
                await mesge.add_reaction('✅')
                await mesge.add_reaction('❌')
                try:
                    reaction, ctx.author = await app.wait_for(' reaction_add', timeout = 20, check = lambda reaction, author1: author1 == ctx.message.author and str(reaction.emoji) in ['✅', '❌'])
                except asyncio.TimeoutError:
                    await ctx.send('시간이 초과되었습니다.')
                else:
                    if str(reaction.emoji) == "❌":
                        await ctx.send("공지 작성을 취소 하였습니다.")
                        await asyncio.sleep(2.5)
                        await mesge.delete()
                    elif str(reaction.emoji) == "✅":
                        await mesge.delete()
                        await app.get_channel(936622193834618890).send('@everyone', embed = discord.Embed(title = f'{text1}', description = f'{text}', color = 0x00ff08).set_footer(text=f'담당 관리자 : {ctx.author.display_name}ㆍ{now}', icon_url=logo_img).set_thumbnail(url=logo_img))
            else:
                await app.get_channel(936622193834618890).send('@everyone', embed = discord.Embed(title = f'{text1}', description = f'{text}', color = 0x00ff08).set_footer(text=f'담당 관리자 : {ctx.author.display_name}ㆍ{now}', icon_url=logo_img) .set_thumbnail(url=logo_img))

        else:
            await ctx.send('명령어 입력이 잘못 되었습니다. \n`notev - 애브리원 안함`, `ev - 애브리원 함`')

    else: 
        await ctx.send(f'입력이 잘못 되었습니다. \n`{app.command_prefix[0]}공지 일동 <ev or notev> <제목> <내용>` , `{app.command_prefix[0]}공지 담당 <ev or notev> <제목> <내용>`')


app.run('OTM2NjIyMzgzNjA1OTAzNDAw.YfP3kQ.Y-cqgq7s2Py6GikHHMFUSEMSiPI')